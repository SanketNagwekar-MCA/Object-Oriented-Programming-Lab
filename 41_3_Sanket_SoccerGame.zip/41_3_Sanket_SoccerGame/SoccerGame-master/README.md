# SoccerGame
This is a java program containing a GUI and logic for a soccer based game
