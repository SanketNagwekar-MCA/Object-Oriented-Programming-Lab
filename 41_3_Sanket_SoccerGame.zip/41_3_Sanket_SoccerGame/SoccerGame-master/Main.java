
/**
 *
 * @author Prithvi Velpuri
 * @version 2: Last Edit 1/18/2017
 */
import java.awt.*;
import javax.swing.*;
import java.io.*;

public class Main extends JFrame
{
    public Main(){
        /*setSize(854,580);
        setTitle("Game");
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);*/
        Menu menu = new Menu();

    }
    public static void main (String [] args){
        new Main();
    }
}
